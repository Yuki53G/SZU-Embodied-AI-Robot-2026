#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
qr_scan_speak_print_test.py

单独二维码测试脚本：
1. 车不动，不发布 /cmd_vel，只订阅相机图像。
2. 扫到二维码后：
   - 终端打印二维码原始内容
   - 判断方向
   - 播报数字内容和方向
3. 没扫到二维码时：
   - 终端周期性打印默认方向
   - 不反复播报，避免一直吵
4. 不保存任何图片文件。

运行：
    source /opt/tros/humble/setup.bash
    source /root/ros2_ws/install/setup.bash
    python3 qr_scan_speak_print_test.py

临时改默认方向：
    python3 qr_scan_speak_print_test.py --default-direction clockwise
    python3 qr_scan_speak_print_test.py --default-direction anticlockwise

换声卡：
    python3 qr_scan_speak_print_test.py --audio-device plughw:2,0
    python3 qr_scan_speak_print_test.py --audio-device default
"""

import argparse
import os
import shutil
import subprocess
import time

import cv2
import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy
from sensor_msgs.msg import CompressedImage


# ============================================================
# 现场只改这里
# ============================================================
USER_IMAGE_TOPIC = "/image"
USER_DEFAULT_DIRECTION = "clockwise"     # clockwise=顺时针；anticlockwise=逆时针
USER_AUDIO_DEVICE = "plughw:0,0"         # 没声可试 plughw:2,0 或 default
USER_SPEECH_ENABLED = True


def normalize_direction(direction: str) -> str:
    d = str(direction).strip().lower()
    if d in ["anticlockwise", "anti", "counterclockwise", "counter", "逆", "逆时针"]:
        return "anticlockwise"
    return "clockwise"


def direction_cn(direction: str) -> str:
    return "逆时针" if normalize_direction(direction) == "anticlockwise" else "顺时针"


def digit_to_cn(ch: str) -> str:
    table = {
        "0": "零", "1": "一", "2": "二", "3": "三", "4": "四",
        "5": "五", "6": "六", "7": "七", "8": "八", "9": "九",
    }
    return table.get(ch, ch)


def speakable_content(raw_text: str) -> str:
    """把二维码内容变成适合中文 TTS 播报的文本。"""
    raw = str(raw_text).strip()
    digits = [c for c in raw if c.isdigit()]

    if digits and len(digits) == len(raw):
        return "数字 " + " ".join(digit_to_cn(c) for c in digits)

    if digits:
        return "内容 " + raw + "，其中数字 " + " ".join(digit_to_cn(c) for c in digits)

    return "内容 " + raw


class QRScanSpeakPrintTest(Node):
    def __init__(self, args):
        super().__init__("qr_scan_speak_print_test")

        self.image_topic = args.image_topic
        self.default_direction = normalize_direction(args.default_direction)
        self.audio_device = args.audio_device
        self.speech_enabled = args.speech_enabled

        self.qr_detector = cv2.QRCodeDetector()

        self.frame_count = 0
        self.decode_count = 0
        self.last_no_qr_print_time = 0.0
        self.last_status_time = 0.0
        self.last_spoken_key = ""
        self.last_speech_time = 0.0

        qos = QoSProfile(
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=10,
        )

        self.sub = self.create_subscription(
            CompressedImage,
            self.image_topic,
            self.image_callback,
            qos,
        )

        self.timer = self.create_timer(1.0, self.status_timer)

        self.print_start_info()
        self.speak_text(f"二维码测试启动，默认方向，{direction_cn(self.default_direction)}。")

    # ============================================================
    # 启动信息
    # ============================================================
    def print_start_info(self):
        print("\n" + "=" * 72, flush=True)
        print("QR SCAN + SPEAK + PRINT TEST", flush=True)
        print("车不会动：本脚本不发布 /cmd_vel，只订阅相机图像。", flush=True)
        print(f"image_topic       = {self.image_topic}", flush=True)
        print(f"default_direction = {self.default_direction}（{direction_cn(self.default_direction)}）", flush=True)
        print(f"audio_device      = {self.audio_device}", flush=True)
        print("数字规则          = 最后一位奇数 -> 顺时针；最后一位偶数 -> 逆时针", flush=True)
        print("单词规则          = A/anti/counter/逆 -> 逆时针；C/clockwise/顺 -> 顺时针", flush=True)
        print("=" * 72 + "\n", flush=True)

    # ============================================================
    # 图像回调
    # ============================================================
    def image_callback(self, msg: CompressedImage):
        self.frame_count += 1

        np_arr = np.frombuffer(msg.data, np.uint8)
        frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

        if frame is None:
            self.print_no_qr("图像帧解码失败 cv2.imdecode=None")
            return

        raw_text, method = self.detect_qr_robust(frame)

        if raw_text:
            raw_text = str(raw_text).strip()
            self.decode_count += 1

            direction = self.decide_direction(raw_text)
            qr_type = self.classify_qr_text(raw_text)

            self.print_decoded_result(raw_text, qr_type, direction, method)
            self.speak_decoded_result(raw_text, direction)
        else:
            self.print_no_qr("当前帧未解出二维码")

    # ============================================================
    # 终端打印
    # ============================================================
    def print_decoded_result(self, raw_text, qr_type, direction, method):
        print("\n" + "=" * 72, flush=True)
        print("扫码成功", flush=True)
        print(f"扫出来的原始内容: {raw_text}", flush=True)
        print(f"内容类型: {qr_type}", flush=True)
        print(f"解码方法: {method}", flush=True)
        print(f"采用方向: {direction}（{direction_cn(direction)}）", flush=True)
        print(f"默认方向: {self.default_direction}（{direction_cn(self.default_direction)}）", flush=True)
        print(f"frame_count={self.frame_count}, decode_count={self.decode_count}", flush=True)
        print("=" * 72 + "\n", flush=True)

    def print_no_qr(self, reason):
        now = time.time()
        if now - self.last_no_qr_print_time < 1.0:
            return
        self.last_no_qr_print_time = now

        print(
            f"[没扫到] {reason} -> 使用默认方向: "
            f"{self.default_direction}（{direction_cn(self.default_direction)}） "
            f"frame_count={self.frame_count}, decode_count={self.decode_count}",
            flush=True,
        )

    def status_timer(self):
        if self.frame_count == 0:
            print(
                f"[状态] 还没收到图像。当前订阅 {self.image_topic}，可检查：ros2 topic list | grep image",
                flush=True,
            )
        else:
            print(
                f"[状态] 正在扫码 frame_count={self.frame_count}, decode_count={self.decode_count}, "
                f"默认={self.default_direction}（{direction_cn(self.default_direction)}）",
                flush=True,
            )

    # ============================================================
    # 二维码识别
    # ============================================================
    def detect_qr_robust(self, frame):
        candidates = []
        h, w = frame.shape[:2]

        candidates.append(("bgr_original", frame))

        # 中心裁剪，减少背景干扰
        for ratio in [0.90, 0.75, 0.60]:
            cw = int(w * ratio)
            ch = int(h * ratio)
            x1 = max(0, (w - cw) // 2)
            y1 = max(0, (h - ch) // 2)
            crop = frame[y1:y1 + ch, x1:x1 + cw]
            if crop.size > 0:
                candidates.append((f"bgr_center_crop_{ratio:.2f}", crop))

        # 放大
        for scale in [1.5, 2.0, 2.5]:
            big = cv2.resize(frame, None, fx=scale, fy=scale, interpolation=cv2.INTER_LINEAR)
            candidates.append((f"bgr_resize_{scale:.1f}", big))

        try:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            candidates.append(("gray", gray))

            eq = cv2.equalizeHist(gray)
            candidates.append(("gray_equalizeHist", eq))

            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
            clahe_img = clahe.apply(gray)
            candidates.append(("gray_CLAHE", clahe_img))

            kernel = np.array([[0, -1, 0],
                               [-1, 5, -1],
                               [0, -1, 0]], dtype=np.float32)
            sharp = cv2.filter2D(gray, -1, kernel)
            candidates.append(("gray_sharpen", sharp))

            _, otsu = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            candidates.append(("gray_otsu", otsu))
            candidates.append(("gray_otsu_invert", 255 - otsu))

            adapt = cv2.adaptiveThreshold(
                gray,
                255,
                cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY,
                31,
                3,
            )
            candidates.append(("gray_adaptive", adapt))
            candidates.append(("gray_adaptive_invert", 255 - adapt))
        except Exception as e:
            print(f"[预处理异常] {e}", flush=True)

        for method, img in candidates:
            text = self.decode_one(img)
            if text:
                return text, method

        return "", ""

    def decode_one(self, img):
        try:
            data, _, _ = self.qr_detector.detectAndDecode(img)
            if data:
                return data

            if hasattr(self.qr_detector, "detectAndDecodeMulti"):
                ok, decoded_info, _, _ = self.qr_detector.detectAndDecodeMulti(img)
                if ok and decoded_info:
                    for item in decoded_info:
                        if item:
                            return item
        except Exception:
            return ""
        return ""

    # ============================================================
    # 内容分类和方向判断
    # ============================================================
    def classify_qr_text(self, raw):
        raw = str(raw).strip()
        digits = [c for c in raw if c.isdigit()]
        letters = [c for c in raw if c.isalpha()]
        lower = raw.lower()

        if len(digits) == 4 and len(digits) == len(raw):
            return "四位数字码"
        if digits and not letters:
            return "数字码"
        if "clock" in lower or "anti" in lower or "counter" in lower:
            return "单词方向码"
        if letters and not digits:
            return "单词/文本码"
        if letters and digits:
            return "数字+字母混合码"
        return "其他文本码"

    def decide_direction(self, raw):
        raw = str(raw).strip()
        lower = raw.lower()

        first_alpha = ""
        for ch in lower:
            if ch.isalpha():
                first_alpha = ch
                break

        if first_alpha == "a":
            return "anticlockwise"
        if first_alpha == "c":
            return "clockwise"

        if "anti" in lower or "counter" in lower or "逆" in raw:
            return "anticlockwise"
        if "clockwise" in lower or "顺" in raw:
            return "clockwise"

        digits = [c for c in raw if c.isdigit()]
        if digits:
            last_digit = int(digits[-1])
            direction = "clockwise" if last_digit % 2 == 1 else "anticlockwise"
            print(
                f"[数字规则] raw=[{raw}] last_digit={last_digit} "
                f"-> {direction}（{direction_cn(direction)}）",
                flush=True,
            )
            return direction

        return self.default_direction

    # ============================================================
    # 播报
    # ============================================================
    def speak_decoded_result(self, raw_text, direction):
        content = speakable_content(raw_text)
        text = f"扫码成功，{content}，{direction_cn(direction)}"

        key = f"{raw_text}|{direction}"
        now = time.time()
        if key == self.last_spoken_key and now - self.last_speech_time < 4.0:
            return

        self.last_spoken_key = key
        self.last_speech_time = now
        self.speak_text(text)

    def speak_text(self, text):
        if not self.speech_enabled:
            return

        print(f"[播报] {text}", flush=True)

        try:
            # 优先 espeak-ng 生成 wav，再 aplay 到指定声卡
            if shutil.which("espeak-ng") and shutil.which("aplay"):
                tmp_wav = "/tmp/qr_scan_speak_print_test.wav"

                subprocess.run(
                    ["espeak-ng", "-v", "zh", "-s", "150", "-w", tmp_wav, text],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=3.0,
                )

                if os.path.exists(tmp_wav):
                    devices = [self.audio_device, "plughw:2,0", "plughw:0,0", "default"]
                    tried = set()

                    for dev in devices:
                        if not dev or dev in tried:
                            continue
                        tried.add(dev)

                        try:
                            ret = subprocess.run(
                                ["aplay", "-q", "-D", dev, tmp_wav],
                                stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL,
                                timeout=5.0,
                            )
                            if ret.returncode == 0:
                                print(f"[播报成功] device={dev}", flush=True)
                                return
                        except Exception:
                            pass

            # 兜底：默认输出
            if shutil.which("espeak-ng"):
                subprocess.Popen(
                    ["espeak-ng", "-v", "zh", "-s", "150", text],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                print("[播报兜底] espeak-ng default", flush=True)
                return

            if shutil.which("espeak"):
                subprocess.Popen(
                    ["espeak", text],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                print("[播报兜底] espeak default", flush=True)
                return

            print("[播报失败] 没有找到 espeak-ng / espeak / aplay", flush=True)

        except Exception as e:
            print(f"[播报异常] {e}", flush=True)


def parse_args():
    parser = argparse.ArgumentParser(description="QR scan + speak + terminal print test. No robot movement.")
    parser.add_argument("--image-topic", default=USER_IMAGE_TOPIC)
    parser.add_argument("--default-direction", default=USER_DEFAULT_DIRECTION, choices=["clockwise", "anticlockwise"])
    parser.add_argument("--audio-device", default=USER_AUDIO_DEVICE)
    parser.add_argument("--no-speech", action="store_true")
    args = parser.parse_args()
    args.speech_enabled = USER_SPEECH_ENABLED and (not args.no_speech)
    return args


def main():
    args = parse_args()
    rclpy.init()
    node = QRScanSpeakPrintTest(args)

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        print("\n[退出] KeyboardInterrupt", flush=True)
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
