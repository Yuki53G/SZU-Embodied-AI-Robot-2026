#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import cv2
import numpy as np

class CVFollower(Node):
    def __init__(self):
        super().__init__('cv_line_follower')
        self.get_logger().info("Start CV line follower.")
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        self.twist = Twist()

        # 打开摄像头
        self.cap = cv2.VideoCapture('/dev/video0')
        if not self.cap.isOpened():
            self.get_logger().error("Cannot open /dev/video0")
            exit(1)

        self.timer = self.create_timer(0.03, self.timer_callback)  # 约30fps

    def timer_callback(self):
        ret, frame = self.cap.read()
        if not ret:
            return

        # 转灰度 & 二值化黑线
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        _, mask = cv2.threshold(gray, 80, 255, cv2.THRESH_BINARY_INV)

        h, w = gray.shape
        search_top = int(h/2)
        search_bot = int(h/2 + 20)
        mask[0:search_top, 0:w] = 0
        mask[search_bot:h, 0:w] = 0

        M = cv2.moments(mask)

        if M['m00'] > 0:
            cx = int(M['m10']/M['m00'])
            err = cx - w/2
            self.twist.linear.x = 0.08
            self.twist.angular.z = -float(err)/400
        else:
            self.twist.linear.x = 0.0
            self.twist.angular.z = 0.0

        self.cmd_vel_pub.publish(self.twist)

def main(args=None):
    rclpy.init(args=args)
    node = CVFollower()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.cap.release()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
