#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rclpy, cv2, cv_bridge, numpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist

class Follower(Node):
    def __init__(self):
        super().__init__('line_follower')
        self.get_logger().info("Start line follower.")

        self.bridge = cv_bridge.CvBridge()
        self.image_sub = self.create_subscription(Image, '/image', self.image_callback, 10)
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        self.pub = self.create_publisher(Image, '/camera/process_image', 10)
        self.twist = Twist()
        
        # Improved parameters
        self.base_speed = 0.15  # Increased from 0.08 for faster line following
        self.max_angular_velocity = 0.8  # Max rotation speed
        self.error_threshold = 50  # Max allowed deviation before reducing speed
        self.line_lost_count = 0
        self.max_lost_frames = 5

    def image_callback(self, msg):
        image = self.bridge.imgmsg_to_cv2(msg, 'bgr8')

        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Improved thresholding with Gaussian blur for better stability
        gray_blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        _, mask = cv2.threshold(gray_blurred, 80, 255, cv2.THRESH_BINARY_INV)

        h, w, d = image.shape
        search_top = int(h / 2)
        search_bot = int(h / 2 + 20)
        mask[0:search_top, 0:w] = 0
        mask[search_bot:h, 0:w] = 0

        M = cv2.moments(mask)

        if M['m00'] > 0:
            self.line_lost_count = 0
            cx = int(M['m10'] / M['m00'])
            cy = int(M['m01'] / M['m00'])
            cv2.circle(image, (cx, cy), 20, (0, 0, 255), -1)

            err = cx - w / 2
            
            # Adaptive speed control based on error magnitude
            # Reduce speed when turning sharply to maintain control
            error_magnitude = abs(err)
            if error_magnitude > self.error_threshold:
                speed_reduction = min(error_magnitude / (w / 2), 1.0)
                self.twist.linear.x = self.base_speed * (1.0 - speed_reduction * 0.5)
            else:
                self.twist.linear.x = self.base_speed
            
            # Improved angular control with dynamic scaling
            self.twist.angular.z = -float(err) / 300  # Adjusted from 400 for better response
            
            # Clamp angular velocity
            if self.twist.angular.z > self.max_angular_velocity:
                self.twist.angular.z = self.max_angular_velocity
            elif self.twist.angular.z < -self.max_angular_velocity:
                self.twist.angular.z = -self.max_angular_velocity
                
            self.cmd_vel_pub.publish(self.twist)
        else:
            # Line lost - gradual stop instead of immediate stop
            self.line_lost_count += 1
            if self.line_lost_count < self.max_lost_frames:
                # Keep previous velocities for smooth continuation
                self.twist.linear.x *= 0.7  # Gradual deceleration
            else:
                self.twist.linear.x = 0.0
                self.twist.angular.z = 0.0
            
            self.cmd_vel_pub.publish(self.twist)

        self.pub.publish(self.bridge.cv2_to_imgmsg(image, 'bgr8'))

def main(args=None):
    rclpy.init(args=args)
    follower = Follower()
    rclpy.spin(follower)
    follower.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
