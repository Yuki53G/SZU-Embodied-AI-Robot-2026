#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage


class QRTerminalReader(Node):
    def __init__(self):
        super().__init__('qr_terminal_reader')
        self.detector = cv2.QRCodeDetector()
        self.last_text = ''
        self.last_print_time = 0.0

        self.sub = self.create_subscription(
            CompressedImage,
            '/image',
            self.image_callback,
            10
        )

        self.get_logger().warn('QR terminal reader started. Subscribing /image')

    def image_callback(self, msg):
        try:
            arr = np.frombuffer(msg.data, np.uint8)
            frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            if frame is None:
                return

            text = self.detect_qr(frame)
            if not text:
                return

            now = time.time()
            if text != self.last_text or now - self.last_print_time > 2.0:
                self.last_text = text
                self.last_print_time = now

                direction = self.classify_direction(text)
                self.get_logger().warn(f'QR TEXT: [{text}]  direction={direction}')

        except Exception as e:
            self.get_logger().warn(f'image_callback error: {e}')

    def detect_qr(self, frame):
        data, _, _ = self.detector.detectAndDecode(frame)
        if data:
            return data.strip()

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        data, _, _ = self.detector.detectAndDecode(gray)
        if data:
            return data.strip()

        eq = cv2.equalizeHist(gray)
        data, _, _ = self.detector.detectAndDecode(eq)
        if data:
            return data.strip()

        big = cv2.resize(eq, None, fx=1.6, fy=1.6, interpolation=cv2.INTER_LINEAR)
        data, _, _ = self.detector.detectAndDecode(big)
        if data:
            return data.strip()

        return ''

    def classify_direction(self, text):
        lower = text.lower()

        if 'anti' in lower or 'counter' in lower or '逆' in text:
            return 'anticlockwise'

        if 'clockwise' in lower or '顺' in text:
            return 'clockwise'

        digits = [c for c in text if c.isdigit()]
        if digits:
            last_digit = int(digits[-1])
            return 'clockwise' if last_digit % 2 == 1 else 'anticlockwise'

        return 'unknown'


def main():
    rclpy.init()
    node = QRTerminalReader()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
