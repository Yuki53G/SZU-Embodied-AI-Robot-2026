import cv2
import yaml
import math
import os
import numpy as np

yaml_path = "/root/ros2_ws/maps/originbot_competition_map.yaml"
out_path = "/root/ros2_ws/maps/map_with_waypoints_v2.png"

waypoints = {
    "P_START": (-0.373, -0.222),
    "QR_POINT": (3.201, 1.625),
    "B_ENTRY": (1.065, 1.628),
    "C_ENTRY": (1.100, 2.569),
    "C_LEFT_DOWN": (-0.836, 2.535),
    "C_LEFT_UP": (-1.241, 3.637),
    "C_RIGHT_UP": (2.125, 4.803),
    "C_RIGHT_DOWN": (2.530, 3.701),
}

route_clockwise = [
    "P_START",
    "QR_POINT",
    "B_ENTRY",
    "C_ENTRY",
    "C_LEFT_DOWN",
    "C_LEFT_UP",
    "C_RIGHT_UP",
    "C_RIGHT_DOWN",
    "C_ENTRY",
    "B_ENTRY",
    "P_START",
]

with open(yaml_path, "r") as f:
    data = yaml.safe_load(f)

image_file = data["image"]
resolution = float(data["resolution"])
origin_x, origin_y, origin_yaw = data["origin"]

pgm_path = image_file
if not os.path.isabs(pgm_path):
    pgm_path = os.path.join(os.path.dirname(yaml_path), image_file)

img = cv2.imread(pgm_path, cv2.IMREAD_GRAYSCALE)
if img is None:
    raise RuntimeError(f"Failed to read map image: {pgm_path}")

h, w = img.shape

# 放大显示，方便看清
scale = 4
color = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
color = cv2.resize(color, (w * scale, h * scale), interpolation=cv2.INTER_NEAREST)

def map_to_pixel(x, y):
    """
    map坐标 -> 图片像素坐标。
    兼容 origin_yaw，虽然你的地图大概率 yaw=0。
    """
    dx = x - origin_x
    dy = y - origin_y

    c = math.cos(-origin_yaw)
    s = math.sin(-origin_yaw)

    mx = c * dx - s * dy
    my = s * dx + c * dy

    px = int(mx / resolution)
    py = int((h - 1) - my / resolution)

    return px * scale, py * scale

# 先画路线
for a, b in zip(route_clockwise[:-1], route_clockwise[1:]):
    if a not in waypoints or b not in waypoints:
        continue
    p1 = map_to_pixel(*waypoints[a])
    p2 = map_to_pixel(*waypoints[b])
    cv2.line(color, p1, p2, (255, 0, 0), 3)

# 每个点的文字偏移，避免重叠
offsets = {
    "P_START": (12, 35),
    "QR_POINT": (12, -15),
    "B_ENTRY": (12, 35),
    "C_ENTRY": (12, -20),
    "C_LEFT_DOWN": (-180, 40),
    "C_LEFT_UP": (-180, -20),
    "C_RIGHT_UP": (12, -20),
    "C_RIGHT_DOWN": (12, 35),
}

# 画点和标签
for idx, (name, (x, y)) in enumerate(waypoints.items(), start=1):
    px, py = map_to_pixel(x, y)

    cv2.circle(color, (px, py), 10, (0, 0, 255), -1)
    cv2.circle(color, (px, py), 16, (0, 0, 255), 2)

    ox, oy = offsets.get(name, (12, -12))
    text = f"{idx}:{name}"

    cv2.putText(
        color,
        text,
        (px + ox, py + oy),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.75,
        (0, 0, 255),
        2,
        cv2.LINE_AA
    )

# 右上角写地图信息
info = f"res={resolution}, origin=({origin_x:.2f},{origin_y:.2f},{origin_yaw:.2f}), size={w}x{h}"
cv2.putText(
    color,
    info,
    (20, 35),
    cv2.FONT_HERSHEY_SIMPLEX,
    0.7,
    (0, 120, 255),
    2,
    cv2.LINE_AA
)

cv2.imwrite(out_path, color)

print("Saved:", out_path)
print("Map image:", pgm_path)
print("resolution:", resolution)
print("origin:", data["origin"])
print("size:", w, h)

for name, (x, y) in waypoints.items():
    px, py = map_to_pixel(x, y)
    print(f"{name:14s} map=({x:.3f}, {y:.3f}) pixel=({px}, {py})")